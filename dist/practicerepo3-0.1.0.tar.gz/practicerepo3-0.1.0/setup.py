from setuptools import setup, find_packages

setup(
    name="practiceRepo3",                               # Nombre del paquete
    version="0.1.0",                                    # Versión inicial
    packages=find_packages(),                           # Paquetes a incluir
    description="Un paquete pip simple de saludo",      # Breve descripción
    author="vanDevBett",                                # Tu nombre
    author_email="juan.k.ita@hotmail.es",               # Tu correo electrónico
    url="https://github.com/vanDevBett/practiceRepo3",  # URL del proyecto
)